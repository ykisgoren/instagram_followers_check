document.getElementById("startBtn").addEventListener("click", async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
    if (tab.url.includes("instagram.com")) {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["analyzer.js"]
      });
      window.close();
    } else {
      alert("Please go to your Instagram profile page first! / Lütfen önce Instagram profil sayfana git!");
    }
  });